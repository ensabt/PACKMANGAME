#include "projectpack.h"

int main()
{
    int command , Counter , i, hardd;
    for(i=0 ; i < users_num ; ++i)
    {
        player[i].is_valid = 0;
        player[i].Status = 0;
        player[i].score =0;
        player[i].level= 0;
    }
    pack();
    Read_fromfile();
    Counter = login();
    while(true)
    {
        printf("Please select the game difficulty. Enter 1 for hard, 2 for medium, and 3 for easy.\n");
        scanf("%d", &command);
        if(command != 1 && command!= 2 &&command!=3)
        {
            printf("The entered number is not valid.\n");
        }
        else
        {
            break;;
        }
    }
    while (true)
    {
        printf("Do you want the game to become even harder?to increase the difficulty of the game, enter 1; otherwise, enter 0.\n");
        scanf("%d" , &hardd);
        if(hardd!= 1 && hardd != 0)
        {
            printf("The entered number is not valid.\n");
        }
        else
        {
            break;
        }
    }
    setup(command , Counter);
    start();
    draw(command , Counter);  
    while (true)
    {
        find(command);
        input();
        logic(command, Counter);
        Move_Ghost(Counter , command , hardd);
        big_map(command);
        draw1(command , Counter);  
        Sleep(50);
    }
}
